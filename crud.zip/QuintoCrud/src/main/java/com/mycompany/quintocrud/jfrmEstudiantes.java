/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.quintocrud;

import com.formdev.flatlaf.themes.FlatMacDarkLaf;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.plaf.basic.BasicListUI;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Usuario
 */
public class jfrmEstudiantes extends javax.swing.JFrame {

    /**
     * Creates new form jfrmEstudiante
     */
    private StudentApiConsumer apiCostumer;
    private final String[] columna = {"Cedula", "Nombre", "Apellido", "Direccion", "Telefono"};
    private DefaultTableModel modeloTabla;

    public jfrmEstudiantes() {
        initComponents();
        this.apiCostumer = new StudentApiConsumer();
        this.modeloTabla = new DefaultTableModel(columna, 0);
        this.jtblEstudiantes.setModel(modeloTabla);
        cargarEstudiantes();
        selectTable();
    }

    private void cargarEstudiantes() {
        this.modeloTabla.setNumRows(0);
        apiCostumer.getAll().forEach(Student -> {
            this.modeloTabla.addRow(new Object[]{Student.getID(), Student.getFirstName(), Student.getLastName(),
                Student.getAddress(), Student.getPhone()});
        });
    }

    private void limpiarLabels() {
        jlblErrorCedula.setText("");
        jlblNombre.setText("");
        jlblApellido.setText("");
        jlblDireccion.setText("");
        jlblTElefono.setText("");
    }

    private void limpiarCampos() {
        jtxtCedula.setText("");
        jtxtNombre.setText("");
        jtxtApellido.setText("");
        jtxtDireccion.setText("");
        jtxtTelefono.setText("");

    }

    private void nuevoEstudiante() {
        String cedula = jtxtCedula.getText();
        String nombre = jtxtNombre.getText();
        String apellido = jtxtApellido.getText();
        String direccion = jtxtDireccion.getText();
        String telefono = jtxtTelefono.getText();
        if (!validarCampos(cedula, nombre, apellido, direccion, telefono)) {
            return;
        }
        Student student = new Student(cedula, nombre, apellido, direccion, telefono);

        if (apiCostumer.create(student)) {
            JOptionPane.showMessageDialog(rootPane, "Estudiante creado correctamente");
            cargarEstudiantes();
            limpiarCampos();
        }
    }

    public void selectTable() {
        jtblEstudiantes.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int row = jtblEstudiantes.getSelectedRow();
                if (row != -1) {
                    jtxtCedula.setText(jtblEstudiantes.getValueAt(row, 0).toString());
                    jtxtNombre.setText(jtblEstudiantes.getValueAt(row, 1).toString());
                    jtxtApellido.setText(jtblEstudiantes.getValueAt(row, 2).toString());
                    jtxtDireccion.setText(jtblEstudiantes.getValueAt(row, 3).toString());
                    jtxtTelefono.setText(jtblEstudiantes.getValueAt(row, 4).toString());
                }
            }

        });
    }

    private boolean validarCampos(String... campos) {
        limpiarLabels();
        boolean isValid = true;

        String[] mensajesError = {"La cedula es requerida",
            "El nombre es requerido",
            "El apellido es requerido",
            "La direccoin es requerida",
            "El telefono es requerido"};
        JLabel[] labels = {
            jlblErrorCedula,
            jlblNombre,
            jlblApellido,
            jlblDireccion,
            jlblTElefono
        };

        for (int i = 0; i < campos.length; i++) {
            if (campos[i].isEmpty() && campos[i].isBlank()) {
                labels[i].setText(mensajesError[i]);
                isValid = false;
            }
        }
        return isValid;
    }

    public void eliminarEstudiante() {
        int row = jtblEstudiantes.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(rootPane, "Debe seleccionar un estudiante");
            return;
        }
        String cedula = jtblEstudiantes.getValueAt(row, 0).toString();
        if (apiCostumer.delete(cedula)) {
            JOptionPane.showMessageDialog(rootPane, "Eliminado correctamente");
            limpiarCampos();
            limpiarLabels();
        }
        cargarEstudiantes();
    }

    public void editarEstudiante() {
        int row = jtblEstudiantes.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(rootPane, "Seleccione un estudiante", "Error", JOptionPane.ERROR_MESSAGE, null);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(rootPane, "¿Está seguro de editar el estudiante?", "Confirmar", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (confirm == JOptionPane.NO_OPTION) {
            return;
        }

        String cedula = jtblEstudiantes.getValueAt(row, 0).toString();
        String nombre = jtxtNombre.getText();
        String apellido = jtxtApellido.getText();
        String direccion = jtxtDireccion.getText();
        String telefono = jtxtTelefono.getText();

        if (!validarCampos(cedula, nombre, apellido, direccion, telefono)) {
            return;
        }

        Student student = new Student(cedula, nombre, apellido, direccion, telefono);

        if (apiCostumer.update(student)) {
            cargarEstudiantes();
            limpiarCampos();
            JOptionPane.showMessageDialog(rootPane, "Estudiante actualizado correctamente");
        } else {
            JOptionPane.showMessageDialog(rootPane, "Error al actualizar el estudiante", "Error", JOptionPane.ERROR_MESSAGE, null);
        }
    }
    
    private void buscarEstudiantes(String term) {
    // Limpiamos la tabla
    this.modeloTabla.setNumRows(0);

    // Si el término de búsqueda está vacío, cargamos todos los estudiantes y salimos
    if (term.isEmpty()) {
        cargarEstudiantes();
        return;
    }

    // Convertimos el término de búsqueda a minúsculas para hacer la búsqueda sin distinción de mayúsculas/minúsculas
    String termLowerCase = term.toLowerCase();

    // Iteramos sobre todos los estudiantes y agregamos aquellos cuyos números de cédula coincidan con el término de búsqueda
    apiCostumer.getAll().forEach(Student -> {
        if (Student.getID().toLowerCase().contains(termLowerCase)) {
            this.modeloTabla.addRow(new Object[]{Student.getID(), Student.getFirstName(), Student.getLastName(),
                    Student.getAddress(), Student.getPhone()});
        }
    });
}



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jtxtCedula = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jtxtNombre = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jtxtApellido = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jtxtDireccion = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jtxtTelefono = new javax.swing.JTextField();
        jbtnNuevo = new javax.swing.JButton();
        jbtnEditar = new javax.swing.JButton();
        jbtnEliminar = new javax.swing.JButton();
        jbtnLimpiar = new javax.swing.JButton();
        jlblErrorCedula = new javax.swing.JLabel();
        jlblNombre = new javax.swing.JLabel();
        jlblApellido = new javax.swing.JLabel();
        jlblDireccion = new javax.swing.JLabel();
        jlblTElefono = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtblEstudiantes = new javax.swing.JTable();
        txtBuscar = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Formulario Estudiantes");

        jLabel2.setText("Cedula:");

        jLabel3.setText("Nombre:");

        jLabel4.setText("Apellido:");

        jLabel5.setText("Direccion:");

        jLabel6.setText("Telefono:");

        jbtnNuevo.setText("Nuevo");
        jbtnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnNuevoActionPerformed(evt);
            }
        });

        jbtnEditar.setText("Editar");
        jbtnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnEditarActionPerformed(evt);
            }
        });

        jbtnEliminar.setText("Eliminar");
        jbtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnEliminarActionPerformed(evt);
            }
        });

        jbtnLimpiar.setText("Limpiar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(259, 259, 259)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(jbtnNuevo)
                        .addGap(45, 45, 45)
                        .addComponent(jbtnEditar)
                        .addGap(40, 40, 40)
                        .addComponent(jbtnEliminar)
                        .addGap(47, 47, 47)
                        .addComponent(jbtnLimpiar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlblErrorCedula)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jtxtCedula)
                                .addComponent(jtxtNombre)
                                .addComponent(jtxtApellido)
                                .addComponent(jtxtDireccion)
                                .addComponent(jtxtTelefono, javax.swing.GroupLayout.DEFAULT_SIZE, 478, Short.MAX_VALUE))
                            .addComponent(jlblNombre)
                            .addComponent(jlblApellido)
                            .addComponent(jlblDireccion)
                            .addComponent(jlblTElefono))))
                .addContainerGap(49, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jtxtCedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblErrorCedula)
                .addGap(4, 4, 4)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jtxtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addComponent(jlblNombre)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jtxtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(1, 1, 1)
                .addComponent(jlblApellido)
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jtxtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(jlblDireccion)
                .addGap(1, 1, 1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jtxtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jlblTElefono)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbtnNuevo)
                    .addComponent(jbtnEditar)
                    .addComponent(jbtnEliminar)
                    .addComponent(jbtnLimpiar))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jtblEstudiantes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jtblEstudiantes);

        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });

        jLabel7.setText("Buscar:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 596, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
            .addGroup(layout.createSequentialGroup()
                .addGap(132, 132, 132)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnNuevoActionPerformed
        // TODO add your handling code here:
        nuevoEstudiante();
    }//GEN-LAST:event_jbtnNuevoActionPerformed

    private void jbtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnEliminarActionPerformed
        // TODO add your handling code here:
        eliminarEstudiante();
    }//GEN-LAST:event_jbtnEliminarActionPerformed

    private void jbtnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnEditarActionPerformed
        // TODO add your handling code here:
        editarEstudiante();
    }//GEN-LAST:event_jbtnEditarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        // TODO add your handling code here:
        buscarEstudiantes(txtBuscar.getText());
    }//GEN-LAST:event_txtBuscarKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(jfrmEstudiantes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(jfrmEstudiantes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(jfrmEstudiantes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(jfrmEstudiantes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        FlatMacDarkLaf.setup();
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new jfrmEstudiantes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbtnEditar;
    private javax.swing.JButton jbtnEliminar;
    private javax.swing.JButton jbtnLimpiar;
    private javax.swing.JButton jbtnNuevo;
    private javax.swing.JLabel jlblApellido;
    private javax.swing.JLabel jlblDireccion;
    private javax.swing.JLabel jlblErrorCedula;
    private javax.swing.JLabel jlblNombre;
    private javax.swing.JLabel jlblTElefono;
    private javax.swing.JTable jtblEstudiantes;
    private javax.swing.JTextField jtxtApellido;
    private javax.swing.JTextField jtxtCedula;
    private javax.swing.JTextField jtxtDireccion;
    private javax.swing.JTextField jtxtNombre;
    private javax.swing.JTextField jtxtTelefono;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
